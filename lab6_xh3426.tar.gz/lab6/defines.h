typedef char* byte_ptr;
#define KB 1024
#define MB 1024*1024
#define HEAP_SIZE 32*MB